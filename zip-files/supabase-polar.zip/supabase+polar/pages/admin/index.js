import Admin from "../../app/admin";

export default Admin;

