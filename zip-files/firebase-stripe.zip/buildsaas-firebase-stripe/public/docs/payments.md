# Payments

SAAS starter boilerplate integrates with Stripe for subscription and payment management. This document covers payment setup, checkout flow, webhooks, and subscription management.

## Payment Provider: Stripe

Stripe is a comprehensive payment platform designed for SaaS applications, handling subscriptions, one-time payments, and customer management.

### Setup

1. **Create Stripe Account**
   - Visit [stripe.com](https://stripe.com)
   - Sign up for an account
   - Complete business verification

2. **Create Products and Prices**
   - Navigate to Products section in Stripe Dashboard
   - Create products (e.g., "Basic Plan", "Pro Plan")
   - Create prices for each product with billing intervals (monthly, yearly)
   - Note the Price IDs (they start with `price_`)

3. **Get API Credentials**
   - Navigate to Developers → API keys
   - Copy your Secret Key (starts with `sk_`)
   - Add to `.env.local`:

   ```env
   STRIPE_SECRET_KEY=your_stripe_secret_key
   STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret
   ```

4. **Configure Webhook**
   
   **For Production:**
   - Go to Developers → Webhooks in Stripe Dashboard
   - Click "Add endpoint"
   - Set endpoint URL: `https://yourdomain.com/api/stripe/webhook`
   - Select events to receive (recommended: `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.payment_succeeded`, `invoice.payment_failed`)
   - Save webhook configuration
   - Copy the webhook signing secret and add it to `.env.local` as `STRIPE_WEBHOOK_SECRET`
   
   **For Local Testing:**
   - Install ngrok: `npm install -g ngrok` or download from [ngrok.com](https://ngrok.com)
   - Start your local server: `npm run dev` (runs on port 3000)
   - In a new terminal, run: `ngrok http 3000`
   - Copy the ngrok URL (e.g., `https://abc123.ngrok.io`)
   - In Stripe Dashboard → Developers → Webhooks, click "Add endpoint"
   - Set webhook URL: `https://abc123.ngrok.io/api/stripe/webhook`
   - Select events to receive
   - Save webhook configuration
   - Copy the webhook signing secret and add it to `.env.local` as `STRIPE_WEBHOOK_SECRET`
   - Now webhooks from Stripe will be forwarded to your local server

## Checkout Flow

### Creating Checkout Session

**API Endpoint**: `POST /api/stripe/checkout`

**Request**:
```javascript
const response = await fetch('/api/stripe/checkout', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    planId: 'price_stripe_price_id',
    customerId: 'optional_customer_id',
    userEmail: 'optional_user_email'
  })
});
```

**Response**:
```json
{
  "checkoutUrl": "https://checkout.stripe.com/...",
  "checkoutId": "checkout_session_id"
}
```

**Process**:
1. Client calls checkout API
2. Server creates Stripe checkout session
3. Checkout record saved to Firestore
4. Returns checkout URL
5. Client redirects user to Stripe checkout
6. User completes payment
7. Stripe redirects back with success status

### Frontend Implementation

```javascript
const handleCheckout = async (planId) => {
  try {
    const response = await fetch('/api/stripe/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ planId })
    });
    
    const { checkoutUrl } = await response.json();
    window.location.href = checkoutUrl;
  } catch (error) {
    console.error('Checkout error:', error);
  }
};
```

## Webhooks

Stripe sends webhook events for payment and subscription changes.

### Webhook Endpoint

**Location**: `pages/api/stripe/webhook.js`

**Security**: Webhook signature verification using Stripe's signing secret

```javascript
// Signature verification
const sig = req.headers['stripe-signature'];
const event = stripe.webhooks.constructEvent(
  req.body,
  sig,
  STRIPE_WEBHOOK_SECRET
);
```

### Webhook Events

**Important Webhook Features:**
- **Customer Preservation**: Customers are **never deleted** - only their status is updated to `"canceled"` or `"past_due"` when subscriptions end. All customer history is preserved.
- **Price ID Storage**: The webhook stores Stripe **Price IDs** (e.g., `price_1SjSw2GLY7dXLvjRXS42FloL`) in the `planId` field, ensuring proper matching with pricing page plans.
- **Amount Handling**: For $0 plans, amounts are stored as `0` (not null/undefined) and displayed correctly as "$0.00" in admin tables.
- **Email Deduplication**: Initial subscription emails are sent once via `checkout.session.completed`. Recurring payment emails are sent via `invoice.payment_succeeded` (skips initial subscription creation to avoid duplicates).
- **Data Extraction**: The webhook correctly extracts Price IDs, Product IDs, customer emails, and amounts from invoice objects, handling both expanded and non-expanded Stripe objects.

#### Subscription Events

**`customer.subscription.created`**: New subscription created
- Store customer and subscription data with correct Price ID
- Update customer status to "active"
- Store amount (handles $0 plans correctly)
- Send confirmation email

**`customer.subscription.updated`**: Subscription updated
- Update subscription status (active, canceled, past_due)
- Update customer record with latest Price ID and plan info
- Add `canceledAt` timestamp if subscription is cancelled
- Send update/cancellation email if needed
- **Never deletes customer** - only updates status

**`customer.subscription.deleted`**: Subscription canceled
- Update customer status to "canceled"
- Preserve all customer data (email, name, plan info, amount)
- Set expiration date
- Add `canceledAt` timestamp
- Send cancellation email
- **Customer record remains in database**

#### Payment Events

**`checkout.session.completed`**: Checkout completed
- Create/update customer record with Price ID
- Create payment record
- Update subscription status to "active"
- Store amount correctly (handles $0 plans)
- Send confirmation email (initial subscription only)

**`invoice.payment_succeeded`**: Payment completed
- Update payment record with correct Price ID and amount
- Update customer record with latest subscription info
- Activate subscription (status: "active")
- Send confirmation email (only for recurring payments, skips initial subscription to avoid duplicate)
- Handles $0 invoices correctly

**`invoice.payment_failed`**: Payment failed
- Update payment status to "failed"
- Update customer status to "past_due"
- Notify customer
- Handle retry logic

#### Customer Events

**`customer.created`**: New customer created
- Store customer data
- Link to user account if applicable

**`customer.updated`**: Customer updated
- Update customer record
- Sync with user data

### Webhook Handler

```javascript
export default async function handler(req, res) {
  // Verify signature
  const sig = req.headers['stripe-signature'];
  const event = stripe.webhooks.constructEvent(
    req.body,
    sig,
    STRIPE_WEBHOOK_SECRET
  );
  
  // Handle event type
  switch (event.type) {
    case 'customer.subscription.created':
      await handleSubscriptionEvent(event);
      break;
    case 'invoice.payment_succeeded':
      await handlePaymentEvent(event);
      break;
    // ... other events
  }
  return res.status(200).json({ received: true });
}
```

## Subscription Management

### Customer Data Structure

**Firestore Collection**: `customers`

```javascript
{
  id: "document_id",
  customerId: "stripe_customer_id",
  subscriptionId: "stripe_subscription_id",
  email: "customer@example.com",
  name: "Customer Name",
  planId: "stripe_price_id",
  planName: "Pro Plan",
  status: "active" | "canceled" | "past_due",
  amount: 29.99,
  currency: "usd",
  expiresAt: "Timestamp",
  createdAt: "Timestamp",
  updatedAt: "Timestamp"
}
```

### Payment Records

**Firestore Collection**: `payments`

```javascript
{
  id: "stripe_payment_id",
  paymentId: "stripe_payment_id",
  customerId: "stripe_customer_id",
  customerEmail: "customer@example.com",
  customerName: "Customer Name",
  amount: 29.99,
  currency: "usd",
  status: "succeeded" | "pending" | "failed",
  planId: "stripe_price_id",
  planName: "Pro Plan",
  subscriptionId: "stripe_subscription_id",
  paymentType: "subscription" | "payment",
  eventType: "invoice.payment_succeeded",
  createdAt: "Timestamp",
  updatedAt: "Timestamp"
}
```

## Canceling Subscriptions

### Cancel Subscription API

**Endpoint**: `POST /api/stripe/cancel-subscription`

**Request**:
```javascript
const response = await fetch('/api/stripe/cancel-subscription', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    subscriptionId: 'stripe_subscription_id',
    customerId: 'stripe_customer_id'
  })
});
```

**Process**:
1. Cancel subscription via Stripe API
2. Update subscription status in Firestore
3. Set expiration date
4. Send cancellation email
5. Return success status

## Payment Utilities

### Location: `lib/utils/stripe/`

#### Payment Utils (`paymentUtils.js`)

```javascript
// Store payment record
storePaymentRecord(paymentData)

// Validate payment data
validatePaymentData(payment)

// Get payment status from subscription
getPaymentStatusFromSubscription(status)

// Verify payment status
verifyPaymentStatus(status, customerId, subscriptionId)
```

#### Customer Utils (`customerUtils.js`)

```javascript
// Enrich customer data
enrichCustomerData(customerId, customerData)

// Store customer record
storeCustomerRecord(customerData)
```

#### Plan Utils (`planUtils.js`)

```javascript
// Enrich plan data
enrichPlanData(customerId, product, subscription)

// Get plan information
getPlanInfo(planId)
```

#### Date Utils (`dateUtils.js`)

```javascript
// Normalize date
normalizeDate(timestamp)

// Get Firestore date
getFirestoreDate(timestamp)
```

## Admin Panel Integration

### Payments Tab

**Location**: `app/admin/components/PaymentsTab.jsx`

**Features**:
- View all payments
- Filter by status, customer, plan
- View payment details
- Export payment data

### Customers Tab

**Location**: `app/admin/components/CustomersTab.jsx`

**Features**:
- View all customers
- View subscription details
- Cancel subscriptions
- View payment history

## Subscription Emails

Automated emails sent for subscription events:

1. **Confirmation Email**: Sent on subscription creation
2. **Cancellation Email**: Sent on subscription cancellation
3. **Upgrade Email**: Sent on plan upgrade

See the **Emailing** section for details.

## Testing Payments

### Test Mode

1. Use Stripe test mode (toggle in Stripe Dashboard)
2. Use test card numbers from Stripe docs
3. Test webhook locally with ngrok
4. Verify data in Firestore

### Test Cards

Stripe provides test card numbers:
- Success: `4242 4242 4242 4242`
- Decline: `4000 0000 0000 0002`
- 3D Secure: `4000 0025 0000 3155`
- Requires authentication: `4000 0027 6000 3184`

### Local Webhook Testing

```bash
# Install ngrok
ngrok http 3000

# Update webhook URL in Stripe Dashboard
# Use ngrok URL: https://your-ngrok-url.ngrok.io/api/stripe/webhook
# Copy the webhook signing secret to .env.local
```

## Error Handling

### Common Errors

1. **Invalid API Key**: Check `STRIPE_SECRET_KEY`
2. **Webhook Verification Failed**: Check `STRIPE_WEBHOOK_SECRET`
3. **Price Not Found**: Verify `planId` exists in Stripe (must be a Price ID starting with `price_`)
4. **Payment Failed**: Check customer payment method

### Error Responses

```javascript
// API errors
{
  error: "Error message",
  details: "Additional information"
}

// Webhook errors
// Logged to console, return 200 to prevent retries
```

## Security Considerations

1. **API Key Security**: Never commit API keys
2. **Webhook Verification**: Always verify signatures
3. **HTTPS**: Use HTTPS for webhook endpoints
4. **Data Validation**: Validate all webhook data
5. **Idempotency**: Handle duplicate webhook events

## Environment Variables

```env
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret
```

## Payment Analytics

Track payment metrics:
- Total revenue
- Active subscriptions
- Churn rate
- Average revenue per user (ARPU)
- Payment success rate

Use Firestore queries or analytics tools to generate reports.

## Best Practices

1. **Webhook Reliability**: Always return 200 to acknowledge receipt
2. **Idempotency**: Check if event already processed
3. **Error Logging**: Log all errors for debugging
4. **Customer Communication**: Send emails for all events
5. **Data Sync**: Keep Firestore in sync with Stripe
6. **Testing**: Test all payment flows thoroughly
7. **Monitoring**: Monitor webhook delivery and errors
