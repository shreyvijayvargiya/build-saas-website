import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../../../utils/firebase";
import getStripe from "../../../lib/utils/getStripe";
import {
	sendSubscriptionConfirmationEmail,
	sendSubscriptionCancellationEmail,
	sendSubscriptionUpgradeEmail,
} from "../../../lib/api/subscriptionEmails";

// Disable body parsing for webhook signature verification
export const config = {
	api: {
		bodyParser: false,
	},
};

// Helper function to normalize dates
const normalizeDate = (timestamp) => {
	if (!timestamp) return null;
	// If it's a Unix timestamp (seconds), convert to milliseconds
	if (typeof timestamp === "number") {
		return new Date(timestamp * 1000);
	}
	// If it's already a Date object
	if (timestamp instanceof Date) {
		return timestamp;
	}
	// Try to parse as date string
	try {
		return new Date(timestamp);
	} catch (error) {
		console.error("Error normalizing date:", error);
		return null;
	}
};

// Helper function to get customer data from Firestore
const getCustomerFromFirestore = async (customerId) => {
	try {
		const customerRef = doc(db, "customers", customerId);
		const customerDoc = await getDoc(customerRef);
		if (customerDoc.exists()) {
			return { id: customerDoc.id, ...customerDoc.data() };
		}
		return null;
	} catch (error) {
		console.error("Error getting customer from Firestore:", error);
		return null;
	}
};

// Helper function to get plan name from Stripe Price/Product
const getPlanName = async (priceId) => {
	try {
		const stripe = getStripe();
		const price = await stripe.prices.retrieve(priceId, {
			expand: ["product"],
		});
		return price.product?.name || price.nickname || "Pro Plan";
	} catch (error) {
		console.error("Error fetching plan name:", error);
		return "Pro Plan";
	}
};

// ============================================================================
// MAIN WEBHOOK HANDLER
// ============================================================================

export default async function handler(req, res) {
	if (req.method !== "POST") {
		return res.status(405).json({ error: "Method not allowed" });
	}

	const sig = req.headers["stripe-signature"];
	const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

	if (!webhookSecret) {
		console.error("Stripe webhook secret not configured");
		return res.status(500).json({ error: "Webhook secret not configured" });
	}

	// Read raw body from request stream
	let rawBody = "";
	await new Promise((resolve, reject) => {
		req.on("data", (chunk) => {
			rawBody += chunk.toString();
		});
		req.on("end", resolve);
		req.on("error", reject);
	});

	let event;

	try {
		// Verify webhook signature with raw body
		const stripe = getStripe();
		event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret);
	} catch (err) {
		console.error("Webhook signature verification failed:", err.message);
		return res.status(400).json({ error: `Webhook Error: ${err.message}` });
	}

	try {
		// Handle different event types
		switch (event.type) {
			case "checkout.session.completed":
				await handleCheckoutCompleted(event);
				break;

			case "customer.subscription.created":
			case "customer.subscription.updated":
				await handleSubscriptionEvent(event);
				break;

			case "customer.subscription.deleted":
				await handleSubscriptionDeleted(event);
				break;

			case "invoice.payment_succeeded":
				await handlePaymentSucceeded(event);
				break;

			case "invoice.payment_failed":
				await handlePaymentFailed(event);
				break;

			case "customer.created":
			case "customer.updated":
				await handleCustomerEvent(event);
				break;

			default:
				console.log("Unhandled event type:", event.type);
		}

		return res.status(200).json({ received: true });
	} catch (error) {
		console.error("Webhook error:", error);
		return res.status(500).json({ error: "Internal server error" });
	}
}

// ============================================================================
// EVENT HANDLERS
// ============================================================================

async function handleCheckoutCompleted(event) {
	const session = event.data.object;

	// Get customer email from session
	const customerEmail = session.customer_details?.email;
	const customerId = session.customer; // Stripe Customer ID
	const subscriptionId = session.subscription;

	if (!customerId || !customerEmail) {
		console.error("Missing customer ID or email in checkout session");
		return;
	}

	// Get subscription details if available
	let subscription = null;
	if (subscriptionId) {
		try {
			const stripe = getStripe();
			subscription = await stripe.subscriptions.retrieve(subscriptionId, {
				expand: ["items.data.price.product"],
			});
		} catch (error) {
			console.error("Error retrieving subscription:", error);
		}
	}

	// Get plan information
	const priceId =
		subscription?.items?.data[0]?.price?.id || session.metadata?.planId;
	const productId =
		subscription?.items?.data[0]?.price?.product?.id ||
		(typeof subscription?.items?.data[0]?.price?.product === "string"
			? subscription.items.data[0].price.product
			: null);
	const planName =
		subscription?.items?.data[0]?.price?.product?.name ||
		subscription?.items?.data[0]?.price?.nickname ||
		(await getPlanName(priceId));

	// Log for debugging
	console.log("handleCheckoutCompleted - Price ID:", priceId);
	console.log("handleCheckoutCompleted - Product ID:", productId);
	console.log("handleCheckoutCompleted - Plan Name:", planName);

	// Ensure we store the Price ID, not Product ID or other IDs
	if (!priceId || !priceId.startsWith("price_")) {
		console.warn("Warning: priceId is not a valid Stripe Price ID:", priceId);
	}

	// Update or create customer in Firestore
	const customerRef = doc(db, "customers", customerId);
	const customerDoc = await getDoc(customerRef);

	const customerData = {
		customerId: customerId,
		subscriptionId: subscriptionId || null,
		email: customerEmail ? customerEmail.toLowerCase().trim() : null,
		name: session.customer_details?.name || customerEmail?.split("@")[0],
		planId: priceId || null,
		planName: planName,
		status: subscription?.status || "active",
		amount:
			subscription?.items?.data[0]?.price?.unit_amount !== undefined
				? subscription.items.data[0].price.unit_amount / 100
				: 0, // Store 0 for free plans, not null/undefined
		currency: subscription?.items?.data[0]?.price?.currency || "usd",
		expiresAt: subscription?.current_period_end
			? normalizeDate(subscription.current_period_end)
			: null,
		updatedAt: serverTimestamp(),
	};

	if (!customerDoc.exists()) {
		customerData.createdAt = serverTimestamp();
	}

	await setDoc(customerRef, customerData, { merge: true });

	// Store payment record
	if (subscription?.items?.data[0]?.price?.unit_amount) {
		const paymentRef = doc(
			db,
			"payments",
			session.payment_intent || `checkout_${session.id}`
		);
		await setDoc(
			paymentRef,
			{
				paymentId: session.payment_intent || `checkout_${session.id}`,
				customerId: customerId,
				customerEmail: customerEmail,
				customerName: customerData.name,
				amount: subscription.items.data[0].price.unit_amount / 100,
				currency: subscription.items.data[0].price.currency || "usd",
				status: "succeeded",
				planId: priceId,
				planName: planName,
				subscriptionId: subscriptionId,
				paymentType: "subscription",
				eventType: event.type,
				createdAt: serverTimestamp(),
				updatedAt: serverTimestamp(),
			},
			{ merge: true }
		);
	}

	// Send confirmation email
	try {
		const expiresAtDate = normalizeDate(customerData.expiresAt);
		await sendSubscriptionConfirmationEmail({
			customerEmail: customerEmail,
			customerName: customerData.name,
			planName: planName,
			amount: customerData.amount,
			currency: customerData.currency,
			paymentId: session.payment_intent || session.id,
			expiresAt: expiresAtDate,
		});
	} catch (error) {
		console.error("Failed to send confirmation email:", error);
	}
}

async function handleSubscriptionEvent(event) {
	const subscription = event.data.object;
	const customerId = subscription.customer;

	if (!customerId) {
		console.error("No customer ID in subscription event");
		return;
	}

	// Get customer details from Stripe
	let customerEmail = null;
	let customerName = null;
	try {
		const stripe = getStripe();
		const customer = await stripe.customers.retrieve(customerId);
		customerEmail = customer.email;
		customerName = customer.name || customer.email?.split("@")[0];
	} catch (error) {
		console.error("Error retrieving customer:", error);
	}

	// Get existing customer data for comparison
	const existingCustomer = await getCustomerFromFirestore(customerId);
	const existingCustomerData = existingCustomer || {};

	// Get plan information
	const priceId = subscription.items?.data[0]?.price?.id;
	const productId =
		subscription.items?.data[0]?.price?.product?.id ||
		(typeof subscription.items?.data[0]?.price?.product === "string"
			? subscription.items.data[0].price.product
			: null);
	const planName =
		subscription.items?.data[0]?.price?.product?.name ||
		subscription.items?.data[0]?.price?.nickname ||
		(await getPlanName(priceId));

	// Log for debugging
	console.log("handleSubscriptionEvent - Price ID:", priceId);
	console.log("handleSubscriptionEvent - Product ID:", productId);
	console.log("handleSubscriptionEvent - Plan Name:", planName);

	const isUpgrade =
		existingCustomerData.planId && existingCustomerData.planId !== priceId;

	const isCancelled =
		subscription.status === "canceled" || subscription.cancel_at_period_end;

	// Determine customer status based on subscription status
	let customerStatus = "active";
	if (subscription.status === "canceled") {
		customerStatus = "canceled";
	} else if (subscription.cancel_at_period_end) {
		customerStatus = "canceled"; // Will cancel at period end
	} else if (
		subscription.status === "past_due" ||
		subscription.status === "unpaid"
	) {
		customerStatus = "past_due";
	} else if (subscription.status === "active") {
		customerStatus = "active";
	} else {
		customerStatus = subscription.status || "active";
	}

	// Update customer in Firestore (NEVER DELETE - only update status)
	const customerRef = doc(db, "customers", customerId);
	const customerDoc = await getDoc(customerRef);

	const updatedCustomerData = {
		customerId: customerId,
		subscriptionId:
			subscription.id || existingCustomerData.subscriptionId || null,
		email: customerEmail
			? customerEmail.toLowerCase().trim()
			: existingCustomerData.email || null,
		name: customerName || existingCustomerData.name,
		planId: priceId || existingCustomerData.planId || null,
		planName: planName,
		status: customerStatus, // Use determined status instead of subscription.status
		amount:
			subscription.items?.data[0]?.price?.unit_amount !== undefined
				? subscription.items.data[0].price.unit_amount / 100
				: existingCustomerData.amount !== undefined
					? existingCustomerData.amount
					: 0,
		currency:
			subscription.items?.data[0]?.price?.currency ||
			existingCustomerData.currency ||
			"usd",
		expiresAt: subscription.current_period_end
			? normalizeDate(subscription.current_period_end)
			: existingCustomerData.expiresAt || null,
		updatedAt: serverTimestamp(),
	};

	// Add canceledAt timestamp if subscription is cancelled
	if (isCancelled && !existingCustomerData.canceledAt) {
		updatedCustomerData.canceledAt = serverTimestamp();
	}

	if (!customerDoc.exists()) {
		updatedCustomerData.createdAt = serverTimestamp();
	}

	await setDoc(customerRef, updatedCustomerData, { merge: true });

	// Store payment record for subscription events
	if (subscription.items?.data[0]?.price?.unit_amount) {
		const paymentId = `sub_${subscription.id}_${subscription.current_period_start || Date.now()}`;
		const paymentRef = doc(db, "payments", paymentId);
		await setDoc(
			paymentRef,
			{
				paymentId: paymentId,
				customerId: customerId,
				customerEmail: customerEmail || existingCustomerData.email,
				customerName: customerName || existingCustomerData.name,
				amount: subscription.items.data[0].price.unit_amount / 100,
				currency: subscription.items.data[0].price.currency || "usd",
				status: subscription.status === "active" ? "succeeded" : "pending",
				planId: priceId,
				planName: planName,
				subscriptionId: subscription.id,
				paymentType: "subscription",
				eventType: event.type,
				createdAt: serverTimestamp(),
				updatedAt: serverTimestamp(),
			},
			{ merge: true }
		);
	}

	// Send appropriate emails
	if (customerEmail) {
		try {
			if (isCancelled) {
				const expiresAtDate = normalizeDate(updatedCustomerData.expiresAt);
				await sendSubscriptionCancellationEmail({
					customerEmail: customerEmail,
					customerName: customerName || existingCustomerData.name,
					planName: planName,
					expiresAt: expiresAtDate,
				});
			} else if (isUpgrade && existingCustomerData.planName) {
				const expiresAtDate = normalizeDate(updatedCustomerData.expiresAt);
				await sendSubscriptionUpgradeEmail({
					customerEmail: customerEmail,
					customerName: customerName || existingCustomerData.name,
					oldPlanName: existingCustomerData.planName,
					newPlanName: planName,
					amount: updatedCustomerData.amount,
					currency: updatedCustomerData.currency,
					expiresAt: expiresAtDate,
				});
			}
		} catch (error) {
			console.error("Failed to send subscription email:", error);
		}
	}
}

async function handleSubscriptionDeleted(event) {
	const subscription = event.data.object;
	const customerId = subscription.customer;

	if (!customerId) {
		console.error("No customer ID in subscription deleted event");
		return;
	}

	// Get existing customer data
	const existingCustomer = await getCustomerFromFirestore(customerId);
	if (!existingCustomer) {
		console.error("Customer not found in Firestore for deletion");
		return;
	}

	// Get customer details from Stripe
	let customerEmail = existingCustomer.email;
	let customerName = existingCustomer.name;
	try {
		const stripe = getStripe();
		const customer = await stripe.customers.retrieve(customerId);
		customerEmail = customer.email || customerEmail;
		customerName = customer.name || customerName;
	} catch (error) {
		console.error("Error retrieving customer:", error);
	}

	// Get plan information
	const priceId = subscription.items?.data[0]?.price?.id;
	const planName =
		subscription.items?.data[0]?.price?.product?.name ||
		subscription.items?.data[0]?.price?.nickname ||
		existingCustomer.planName ||
		(await getPlanName(priceId));

	const expiresAt = subscription.current_period_end
		? normalizeDate(subscription.current_period_end)
		: normalizeDate(existingCustomer.expiresAt);

	// Update customer status to canceled (NEVER DELETE - only update status)
	// Keep all customer data, just mark as canceled
	const customerRef = doc(db, "customers", customerId);
	await setDoc(
		customerRef,
		{
			customerId: customerId,
			subscriptionId:
				subscription.id || existingCustomer.subscriptionId || null,
			email: customerEmail
				? customerEmail.toLowerCase().trim()
				: existingCustomer.email,
			name: customerName || existingCustomer.name,
			planId: priceId || existingCustomer.planId || null,
			planName: planName || existingCustomer.planName,
			status: "canceled", // Set status to canceled, but keep customer record
			amount:
				existingCustomer.amount !== undefined ? existingCustomer.amount : 0,
			currency: existingCustomer.currency || "usd",
			expiresAt: expiresAt,
			canceledAt: serverTimestamp(),
			updatedAt: serverTimestamp(),
		},
		{ merge: true } // Use merge to preserve existing data, only update changed fields
	);

	// Send cancellation email
	if (customerEmail) {
		try {
			const expiresAtDate = normalizeDate(expiresAt);
			await sendSubscriptionCancellationEmail({
				customerEmail: customerEmail,
				customerName: customerName,
				planName: planName,
				expiresAt: expiresAtDate,
			});
		} catch (error) {
			console.error("Failed to send cancellation email:", error);
		}
	}
}

async function handlePaymentSucceeded(event) {
	const invoice = event.data.object;
	const customerId = invoice.customer;
	const subscriptionId = invoice.subscription;

	if (!customerId) {
		console.error("No customer ID in payment succeeded event");
		return;
	}

	// Get customer details - use invoice data first, fallback to API call
	let customerEmail = invoice.customer_email || null;
	let customerName = invoice.customer_name || null;

	// If email/name not in invoice, retrieve from Stripe
	if (!customerEmail || !customerName) {
		try {
			const stripe = getStripe();
			const customer = await stripe.customers.retrieve(customerId);
			customerEmail = customerEmail || customer.email;
			customerName =
				customerName || customer.name || customer.email?.split("@")[0];
		} catch (error) {
			console.error("Error retrieving customer:", error);
		}
	}

	// Get subscription details if available
	let subscription = null;
	if (subscriptionId) {
		try {
			const stripe = getStripe();
			subscription = await stripe.subscriptions.retrieve(subscriptionId, {
				expand: ["items.data.price.product"],
			});
		} catch (error) {
			console.error("Error retrieving subscription:", error);
		}
	}

	// Get plan information from invoice lines (most reliable source)
	// invoice.lines.data[0].price.id is the Price ID
	// invoice.lines.data[0].price.product is a string (Product ID), not an object
	// invoice.lines.data[0].plan.id is also the Price ID
	const priceId =
		invoice.lines?.data[0]?.price?.id ||
		invoice.lines?.data[0]?.plan?.id ||
		subscription?.items?.data[0]?.price?.id;

	const productId =
		invoice.lines?.data[0]?.price?.product ||
		invoice.lines?.data[0]?.plan?.product ||
		subscription?.items?.data[0]?.price?.product?.id ||
		(typeof subscription?.items?.data[0]?.price?.product === "string"
			? subscription.items.data[0].price.product
			: null);

	// Get plan name - try subscription first (has expanded product), then fetch if needed
	let planName = null;
	if (subscription?.items?.data[0]?.price?.product?.name) {
		planName = subscription.items.data[0].price.product.name;
	} else if (subscription?.items?.data[0]?.price?.nickname) {
		planName = subscription.items.data[0].price.nickname;
	} else if (priceId) {
		planName = await getPlanName(priceId);
	}

	// Log for debugging
	console.log("handlePaymentSucceeded - Price ID:", priceId);
	console.log("handlePaymentSucceeded - Product ID:", productId);
	console.log("handlePaymentSucceeded - Plan Name:", planName);
	console.log("handlePaymentSucceeded - Customer Email:", customerEmail);
	console.log("handlePaymentSucceeded - Customer Name:", customerName);

	// Store payment record
	// Use invoice.id as payment ID if payment_intent is null (for $0 invoices)
	const paymentId = invoice.payment_intent || invoice.id;
	const paymentRef = doc(db, "payments", paymentId);

	// Amount is already in cents, convert to dollars
	const amount = invoice.amount_paid ? invoice.amount_paid / 100 : 0;

	await setDoc(
		paymentRef,
		{
			paymentId: paymentId,
			customerId: customerId,
			customerEmail: customerEmail ? customerEmail.toLowerCase().trim() : null,
			customerName: customerName,
			amount: amount,
			currency: invoice.currency || "usd",
			status: "succeeded",
			planId: priceId, // Store Price ID (e.g., "price_1SjSw2GLY7dXLvjRXS42FloL")
			planName: planName,
			subscriptionId: subscriptionId,
			paymentType: "subscription", // This is a subscription payment
			eventType: event.type,
			createdAt: serverTimestamp(),
			updatedAt: serverTimestamp(),
		},
		{ merge: true }
	);

	// Update customer subscription status and planId
	// This ensures the customer record has the correct Price ID stored
	if (subscription || priceId) {
		const customerRef = doc(db, "customers", customerId);
		const customerDoc = await getDoc(customerRef);

		const updateData = {
			status: "active",
			updatedAt: serverTimestamp(),
		};

		// Update planId if we have it and it's different
		if (priceId) {
			updateData.planId = priceId;
		}

		// Update planName if we have it
		if (planName) {
			updateData.planName = planName;
		}

		// Update email and name if we have them
		if (customerEmail) {
			updateData.email = customerEmail.toLowerCase().trim();
		}
		if (customerName) {
			updateData.name = customerName;
		}

		// Update amount from subscription or invoice
		// Priority: subscription > invoice lines
		if (subscription?.items?.data[0]?.price?.unit_amount !== undefined) {
			updateData.amount = subscription.items.data[0].price.unit_amount / 100;
			updateData.currency = subscription.items.data[0].price.currency || "usd";
		} else if (invoice.lines?.data[0]?.price?.unit_amount !== undefined) {
			// Fallback to invoice line item if subscription not available
			updateData.amount = invoice.lines.data[0].price.unit_amount / 100;
			updateData.currency =
				invoice.lines.data[0].price.currency || invoice.currency || "usd";
		} else if (invoice.amount_paid !== undefined) {
			// Last fallback: use invoice amount_paid
			updateData.amount = invoice.amount_paid / 100;
			updateData.currency = invoice.currency || "usd";
		}

		// Update expiresAt from subscription
		if (subscription?.current_period_end) {
			updateData.expiresAt = normalizeDate(subscription.current_period_end);
		}

		if (!customerDoc.exists()) {
			updateData.customerId = customerId;
			updateData.subscriptionId = subscriptionId;
			updateData.createdAt = serverTimestamp();
		}

		await setDoc(customerRef, updateData, { merge: true });

		// Send payment confirmation email only for recurring payments
		// Skip email for initial subscription (billing_reason: "subscription_create")
		// because handleCheckoutCompleted already sends it
		if (customerEmail && invoice.billing_reason !== "subscription_create") {
			try {
				const expiresAtDate = subscription?.current_period_end
					? normalizeDate(subscription.current_period_end)
					: null;
				await sendSubscriptionConfirmationEmail({
					customerEmail: customerEmail,
					customerName: customerName,
					planName: planName,
					amount: amount,
					currency: invoice.currency || "usd",
					paymentId: paymentId,
					expiresAt: expiresAtDate,
				});
			} catch (error) {
				console.error("Failed to send payment confirmation email:", error);
			}
		} else if (invoice.billing_reason === "subscription_create") {
			console.log(
				"Skipping email for initial subscription (already sent by checkout.session.completed)"
			);
		}
	}
}

async function handlePaymentFailed(event) {
	const invoice = event.data.object;
	const customerId = invoice.customer;

	if (!customerId) {
		console.error("No customer ID in payment failed event");
		return;
	}

	// Get customer details
	let customerEmail = null;
	let customerName = null;
	try {
		const stripe = getStripe();
		const customer = await stripe.customers.retrieve(customerId);
		customerEmail = customer.email;
		customerName = customer.name || customer.email?.split("@")[0];
	} catch (error) {
		console.error("Error retrieving customer:", error);
	}

	// Get plan information
	const priceId = invoice.lines?.data[0]?.price?.id;
	const planName =
		invoice.lines?.data[0]?.price?.product?.name ||
		(await getPlanName(priceId));

	// Store payment record
	const paymentRef = doc(db, "payments", invoice.payment_intent || invoice.id);
	await setDoc(
		paymentRef,
		{
			paymentId: invoice.payment_intent || invoice.id,
			customerId: customerId,
			customerEmail: customerEmail,
			customerName: customerName,
			amount: invoice.amount_due / 100,
			currency: invoice.currency || "usd",
			status: "failed",
			planId: priceId,
			planName: planName,
			subscriptionId: invoice.subscription,
			paymentType: "payment",
			eventType: event.type,
			createdAt: serverTimestamp(),
			updatedAt: serverTimestamp(),
		},
		{ merge: true }
	);

	// Update customer subscription status
	const customerRef = doc(db, "customers", customerId);
	await setDoc(
		customerRef,
		{
			status: "past_due",
			updatedAt: serverTimestamp(),
		},
		{ merge: true }
	);
}

async function handleCustomerEvent(event) {
	const customer = event.data.object;

	// Store customer in Firestore
	const customerRef = doc(db, "customers", customer.id);
	const customerDoc = await getDoc(customerRef);

	const customerData = {
		customerId: customer.id,
		email: customer.email || null,
		name: customer.name || customer.email || "Customer",
		updatedAt: serverTimestamp(),
	};

	if (!customerDoc.exists()) {
		customerData.createdAt = serverTimestamp();
	}

	await setDoc(customerRef, customerData, { merge: true });
}
