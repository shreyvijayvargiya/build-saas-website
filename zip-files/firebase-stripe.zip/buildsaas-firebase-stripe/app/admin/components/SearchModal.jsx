import React, { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import Fuse from "fuse.js";
import {
	Search,
	X,
	FileText,
	Mail,
	Users,
	Plus,
	Shield,
	ArrowRight,
	Sparkles,
} from "lucide-react";
import { getAllBlogs } from "../../../lib/api/blog";
import { getAllEmails } from "../../../lib/api/emails";
import { getAllSubscribers } from "../../../lib/api/subscribers";

const SearchModal = ({ isOpen, onClose, onNavigate }) => {
	const [searchQuery, setSearchQuery] = useState("");
	const [selectedCategory, setSelectedCategory] = useState("all"); // all, blogs, emails, subscribers

	// Fetch all data
	const { data: blogs = [] } = useQuery({
		queryKey: ["blogs"],
		queryFn: () => getAllBlogs(),
		enabled: isOpen,
	});

	const { data: emails = [] } = useQuery({
		queryKey: ["emails"],
		queryFn: () => getAllEmails(),
		enabled: isOpen,
	});

	const { data: subscribers = [] } = useQuery({
		queryKey: ["subscribers"],
		queryFn: () => getAllSubscribers(),
		enabled: isOpen,
	});

	// Prepare search data
	const searchData = useMemo(() => {
		const data = [];

		if (selectedCategory === "all" || selectedCategory === "blogs") {
			blogs.forEach((blog) => {
				data.push({
					type: "blog",
					id: blog.id,
					title: blog.title,
					subtitle: blog.slug || blog.author || "",
					searchText: `${blog.title} ${blog.slug || ""} ${blog.author || ""}`,
					data: blog,
				});
			});
		}

		if (selectedCategory === "all" || selectedCategory === "emails") {
			emails.forEach((email) => {
				data.push({
					type: "email",
					id: email.id,
					title: email.subject,
					subtitle: email.status || "draft",
					searchText: `${email.subject} ${email.status || ""}`,
					data: email,
				});
			});
		}

		if (selectedCategory === "all" || selectedCategory === "subscribers") {
			subscribers.forEach((subscriber) => {
				data.push({
					type: "subscriber",
					id: subscriber.id,
					title: subscriber.email,
					subtitle: subscriber.name || "",
					searchText: `${subscriber.email} ${subscriber.name || ""}`,
					data: subscriber,
				});
			});
		}

		return data;
	}, [blogs, emails, subscribers, selectedCategory]);

	// Configure Fuse.js
	const fuse = useMemo(() => {
		return new Fuse(searchData, {
			keys: ["title", "subtitle", "searchText"],
			threshold: 0.3,
			includeScore: true,
		});
	}, [searchData]);

	// Perform search
	const searchResults = useMemo(() => {
		if (!searchQuery.trim()) {
			return [];
		}
		return fuse.search(searchQuery).map((result) => result.item);
	}, [searchQuery, fuse]);

	// Reset search when modal closes
	useEffect(() => {
		if (!isOpen) {
			setSearchQuery("");
			setSelectedCategory("all");
		}
	}, [isOpen]);

	// Handle keyboard shortcuts
	useEffect(() => {
		if (!isOpen) return;

		const handleKeyDown = (e) => {
			if (e.key === "Escape") {
				onClose();
			}
			if ((e.metaKey || e.ctrlKey) && e.key === "k") {
				e.preventDefault();
			}
		};

		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [isOpen, onClose]);

	// Handle result click
	const handleResultClick = (result) => {
		if (result.type === "blog") {
			onNavigate("blogs");
			window.location.href = `/admin/editor/blog?id=${result.id}`;
		} else if (result.type === "email") {
			onNavigate("emails");
			window.location.href = `/admin/editor/email?id=${result.id}`;
		} else if (result.type === "subscriber") {
			onNavigate("subscribers");
		}
		onClose();
	};

	// Guidance actions
	const guidanceActions = [
		{
			icon: FileText,
			label: "Create New Blog",
			action: () => {
				onNavigate("blogs");
				window.location.href = "/admin/editor/blog";
				onClose();
			},
		},
		{
			icon: Mail,
			label: "Create New Email",
			action: () => {
				onNavigate("emails");
				window.location.href = "/admin/editor/email";
				onClose();
			},
		},
		{
			icon: Shield,
			label: "Add Team Member",
			action: () => {
				onNavigate("teams");
				onClose();
			},
		},
		{
			icon: Users,
			label: "Check Subscribers",
			action: () => {
				onNavigate("subscribers");
				onClose();
			},
		},
		{
			icon: Mail,
			label: "Send Email to Subscriber",
			action: () => {
				onNavigate("subscribers");
				onClose();
			},
		},
	];

	const getTypeIcon = (type) => {
		switch (type) {
			case "blog":
				return FileText;
			case "email":
				return Mail;
			case "subscriber":
				return Users;
			default:
				return FileText;
		}
	};

	const getTypeColor = (type) => {
		switch (type) {
			case "blog":
				return "bg-zinc-100 text-zinc-800";
			case "email":
				return "bg-purple-100 text-purple-800";
			case "subscriber":
				return "bg-green-100 text-green-800";
			default:
				return "bg-zinc-100 text-zinc-800";
		}
	};

	return (
		<AnimatePresence>
			{isOpen && (
				<>
					{/* Backdrop */}
					<motion.div
						initial={{ opacity: 0 }}
						animate={{ opacity: 1 }}
						exit={{ opacity: 0 }}
						onClick={onClose}
						className="fixed inset-0 bg-black bg-opacity-50 z-50"
					/>

					{/* Modal */}
					<div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
						<motion.div
							initial={{ scale: 0.95, opacity: 0 }}
							animate={{ scale: 1, opacity: 1 }}
							exit={{ scale: 0.95, opacity: 0 }}
							className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col pointer-events-auto"
						>
							{/* Header */}
							<div className="p-4 border-b border-zinc-200">
								<div className="flex items-center gap-3 mb-3">
									<div className="flex-1 relative">
										<Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-zinc-400" />
										<input
											type="text"
											value={searchQuery}
											onChange={(e) => setSearchQuery(e.target.value)}
											placeholder="Search blogs, emails, subscribers..."
											className="w-full pl-10 pr-4 py-2.5 border border-zinc-300 rounded-xl focus:ring-2 focus:ring-zinc-500 focus:outline-none text-sm"
											autoFocus
										/>
									</div>
									<button
										onClick={onClose}
										className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors rounded-xl hover:bg-zinc-100"
									>
										<X className="w-5 h-5" />
									</button>
								</div>

								
							</div>

							{/* Content */}
							<div className="flex-1 overflow-y-auto p-4">
								{/* Search Results */}
								{searchQuery.trim() && (
									<div className="mb-6">
										{searchResults.length === 0 ? (
											<div className="text-center py-8 text-zinc-500 text-sm">
												No results found for "{searchQuery}"
											</div>
										) : (
											<div className="space-y-1">
												{searchResults.map((result) => {
													const Icon = getTypeIcon(result.type);
													return (
														<motion.button
															key={`${result.type}-${result.id}`}
															whileHover={{ scale: 1.01 }}
															whileTap={{ scale: 0.99 }}
															onClick={() => handleResultClick(result)}
															className="w-full p-3 rounded-xl border border-zinc-200 hover:border-zinc-300 hover:bg-zinc-50 transition-colors text-left flex items-center gap-3"
														>
															<div
																className={`p-2 rounded-xl ${getTypeColor(
																	result.type
																)}`}
															>
																<Icon className="w-4 h-4" />
															</div>
															<div className="flex-1 min-w-0">
																<div className="font-medium text-zinc-900 truncate">
																	{result.title}
																</div>
																{result.subtitle && (
																	<div className="text-xs text-zinc-500 truncate">
																		{result.subtitle}
																	</div>
																)}
															</div>
															<div className="flex items-center gap-2">
																<span
																	className={`px-2 py-0.5 text-xs font-medium rounded ${getTypeColor(
																		result.type
																	)}`}
																>
																	{result.type}
																</span>
																<ArrowRight className="w-4 h-4 text-zinc-400" />
															</div>
														</motion.button>
													);
												})}
											</div>
										)}
									</div>
								)}

								{/* Guidance Section */}
								<div>
									<div className="flex items-center gap-2 mb-3">
										<Sparkles className="w-4 h-4 text-zinc-400" />
										<h3 className="text-sm font-semibold text-zinc-700">
											Quick Actions
										</h3>
									</div>
									<div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
										{guidanceActions.map((action, index) => {
											const Icon = action.icon;
											return (
												<motion.button
													key={index}
													whileHover={{ scale: 1.02 }}
													whileTap={{ scale: 0.98 }}
													onClick={action.action}
													className="p-3 rounded-xl border border-zinc-200 hover:border-zinc-300 hover:bg-zinc-50 transition-colors text-left flex items-center gap-3"
												>
													<div className="p-2 rounded-xl bg-zinc-100 text-zinc-700">
														<Icon className="w-4 h-4" />
													</div>
													<span className="text-sm font-medium text-zinc-900">
														{action.label}
													</span>
													<ArrowRight className="w-4 h-4 text-zinc-400 ml-auto" />
												</motion.button>
											);
										})}
									</div>
								</div>
							</div>

							{/* Footer */}
							<div className="p-4 border-t border-zinc-200 bg-zinc-50">
								<div className="flex items-center justify-between text-xs text-zinc-500">
									<div className="flex items-center gap-4">
										<span>Press Esc to close</span>
									</div>
									<span>
										{searchQuery.trim()
											? `${searchResults.length} result${
													searchResults.length !== 1 ? "s" : ""
												}`
											: `${searchData.length} total items`}
									</span>
								</div>
							</div>
						</motion.div>
					</div>
				</>
			)}
		</AnimatePresence>
	);
};

export default SearchModal;
