import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Trash2, X, Save, Eye, Mail, Search, ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import Fuse from "fuse.js";
import TiptapEditor from "./TiptapEditor";
import TableSkeleton from "../../../lib/ui/TableSkeleton";
import {
	getAllEmails,
	createEmail,
	updateEmail,
	deleteEmail,
} from "../../../lib/api/emails";
import {
	hasPermission,
	getAllowedActions,
} from "../../../lib/config/roles-config";
import { getCachedUserRole, getUserRole } from "../../../lib/utils/getUserRole";
import { getCurrentUserEmail } from "../../../lib/utils/getCurrentUserEmail";
import ConfirmationModal from "../../../lib/ui/ConfirmationModal";
import { toast } from "react-toastify";

const EmailTab = ({ onSendEmail }) => {
	const queryClient = useQueryClient();
	const [showEmailModal, setShowEmailModal] = useState(false);
	const [showEmailPreview, setShowEmailPreview] = useState(false);
	const [editingEmail, setEditingEmail] = useState(null);
	const [emailForm, setEmailForm] = useState({
		subject: "",
		status: "draft",
	});
	const [emailContent, setEmailContent] = useState("");
	const [showSendSingleModal, setShowSendSingleModal] = useState(false);
	const [singleEmailForm, setSingleEmailForm] = useState({
		email: "",
		name: "",
	});
	const [sortField, setSortField] = useState("createdAt");
	const [sortDirection, setSortDirection] = useState("desc");
	const [searchQuery, setSearchQuery] = useState("");

	// Modal states
	const [showConfirmModal, setShowConfirmModal] = useState(false);
	const [confirmAction, setConfirmAction] = useState(null);
	const [confirmData, setConfirmData] = useState({
		title: "",
		message: "",
		variant: "danger",
	});

	// Fetch user role with React Query
	const fetchUserRole = async () => {
		try {
			// Get current user email (from Firebase Auth or localStorage fallback)
			const userEmail = await getCurrentUserEmail();

			console.log("EmailTab: Current user email:", userEmail);

			if (userEmail) {
				// Fetch role from Firestore teams collection using email
				const role = await getUserRole(userEmail, false);
				console.log("EmailTab: Fetched role from teams collection:", role);
				return role;
			} else {
				console.warn("EmailTab: No user email found, using cached role");
				// Fallback to cached role
				return getCachedUserRole();
			}
		} catch (error) {
			console.error("Error fetching user role:", error);
			// Fallback to cached role
			return getCachedUserRole();
		}
	};

	const { data: userRole = "viewer", isLoading: isLoadingRole } = useQuery({
		queryKey: ["userRole"],
		queryFn: fetchUserRole,
		staleTime: 5 * 60 * 1000, // 5 minutes
		cacheTime: 10 * 60 * 1000, // 10 minutes
	});

	// Get allowed actions for emails
	const allowedActions = getAllowedActions(userRole, "emails");

	// Fetch emails with React Query
	const {
		data: emails = [],
		isLoading,
		error,
	} = useQuery({
		queryKey: ["emails"],
		queryFn: () => getAllEmails(),
	});

	// Create email mutation
	const createEmailMutation = useMutation({
		mutationFn: createEmail,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["emails"] });
			handleCloseModal();
			toast.success("Email created successfully!");
		},
		onError: (error) => {
			console.error("Error creating email:", error);
			toast.error("Failed to create email. Please try again.");
		},
	});

	// Update email mutation
	const updateEmailMutation = useMutation({
		mutationFn: ({ id, data }) => updateEmail(id, data),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["emails"] });
			handleCloseModal();
			toast.success("Email updated successfully!");
		},
		onError: (error) => {
			console.error("Error updating email:", error);
			toast.error("Failed to update email. Please try again.");
		},
	});

	// Delete email mutation
	const deleteEmailMutation = useMutation({
		mutationFn: deleteEmail,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["emails"] });
			toast.success("Email deleted successfully!");
		},
		onError: (error) => {
			console.error("Error deleting email:", error);
			toast.error("Failed to delete email. Please try again.");
		},
	});

	// Handle email form change
	const handleEmailFormChange = (e) => {
		const { name, value } = e.target;
		setEmailForm((prev) => ({ ...prev, [name]: value }));
	};

	// Create or update email
	const handleSaveEmail = async () => {
		if (!emailForm.subject || !emailContent) return;

		const emailData = {
			...emailForm,
			content: emailContent,
		};

		if (editingEmail) {
			updateEmailMutation.mutate({ id: editingEmail.id, data: emailData });
		} else {
			createEmailMutation.mutate(emailData);
		}
	};

	// Delete email
	const handleDeleteEmail = async (id) => {
		setConfirmData({
			title: "Delete Email",
			message:
				"Are you sure you want to delete this email? This action cannot be undone.",
			variant: "danger",
		});
		setConfirmAction(() => () => deleteEmailMutation.mutate(id));
		setShowConfirmModal(true);
	};

	// Edit email
	const handleEditEmail = (email) => {
		// Navigate to editor page instead of opening modal
		window.location.href = `/admin/editor/email?id=${email.id}`;
	};

	// Preview email
	const handlePreviewEmail = (email) => {
		setEditingEmail(email);
		setShowEmailPreview(true);
	};

	// Send email
	const handleSendEmail = async (email) => {
		if (onSendEmail) {
			try {
				await onSendEmail(email);
				queryClient.invalidateQueries({ queryKey: ["emails"] });
			} catch (error) {
				console.error("Error sending email:", error);
			}
		}
	};

	// Handle single email form change
	const handleSingleEmailFormChange = (e) => {
		const { name, value } = e.target;
		setSingleEmailForm((prev) => ({ ...prev, [name]: value }));
	};

	// Send email to single user
	const handleSendSingleEmail = async () => {
		if (!singleEmailForm.email) {
			toast.warning("Email address is required");
			return;
		}

		// Validate email format
		const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		if (!emailRegex.test(singleEmailForm.email)) {
			toast.warning("Please enter a valid email address");
			return;
		}

		// Get the current email content and subject
		const currentSubject =
			emailForm.subject || editingEmail?.subject || "No Subject";
		const currentContent = emailContent || editingEmail?.content || "";

		if (!currentContent) {
			toast.warning("Email content is required");
			return;
		}

		try {
			const response = await fetch("/api/emails/send-single", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					email: singleEmailForm.email,
					name: singleEmailForm.name || undefined,
					subject: currentSubject,
					content: currentContent,
				}),
			});

			const data = await response.json();

			if (response.ok) {
				toast.success("Email sent successfully!");
				setShowSendSingleModal(false);
				setSingleEmailForm({ email: "", name: "" });
			} else {
				toast.error(data.error || "Failed to send email");
			}
		} catch (error) {
			console.error("Error sending single email:", error);
			toast.error("Failed to send email. Please try again.");
		}
	};

	// Close modal
	const handleCloseModal = () => {
		setShowEmailModal(false);
		setEditingEmail(null);
		setEmailForm({ subject: "", status: "draft" });
		setEmailContent("");
	};

	// Get current email HTML for preview
	const getEmailPreviewHTML = () => {
		if (showEmailPreview && editingEmail) {
			if (!showEmailModal) {
				return editingEmail.content;
			}
			return emailContent;
		}
		return emailContent;
	};

	// Format date
	const formatDate = (dateString) => {
		if (!dateString) return "N/A";
		const date = dateString?.toDate
			? dateString.toDate()
			: new Date(dateString);
		return date.toLocaleDateString("en-US", {
			year: "numeric",
			month: "short",
			day: "numeric",
		});
	};

	// Configure Fuse.js for email search
	const fuse = useMemo(() => {
		return new Fuse(emails, {
			keys: ["subject", "status"],
			threshold: 0.3,
			includeScore: true,
		});
	}, [emails]);

	// Filter emails by search query using Fuse.js
	const filteredEmails = useMemo(() => {
		if (!searchQuery.trim()) {
			return emails;
		}
		return fuse.search(searchQuery).map((result) => result.item);
	}, [searchQuery, fuse, emails]);

	// Handle column sort
	const handleSort = (field) => {
		if (sortField === field) {
			setSortDirection(sortDirection === "asc" ? "desc" : "asc");
		} else {
			setSortField(field);
			setSortDirection("asc");
		}
	};

	// Get sort icon for column header
	const getSortIcon = (field) => {
		if (sortField !== field) {
			return <ArrowUpDown className="w-3.5 h-3.5 ml-1 text-zinc-400" />;
		}
		return sortDirection === "asc" ? (
			<ArrowUp className="w-3.5 h-3.5 ml-1 text-zinc-900" />
		) : (
			<ArrowDown className="w-3.5 h-3.5 ml-1 text-zinc-900" />
		);
	};

	// Sort filtered emails
	const sortedEmails = [...filteredEmails].sort((a, b) => {
		let aValue, bValue;

		switch (sortField) {
			case "subject":
				aValue = (a.subject || "").toLowerCase();
				bValue = (b.subject || "").toLowerCase();
				break;
			case "status":
				aValue = (a.status || "").toLowerCase();
				bValue = (b.status || "").toLowerCase();
				break;
			case "recipients":
				aValue = a.recipients || 0;
				bValue = b.recipients || 0;
				break;
			case "createdAt":
				aValue = a.createdAt?.toDate
					? a.createdAt.toDate().getTime()
					: new Date(a.createdAt || 0).getTime();
				bValue = b.createdAt?.toDate
					? b.createdAt.toDate().getTime()
					: new Date(b.createdAt || 0).getTime();
				break;
			default:
				return 0;
		}

		if (typeof aValue === "string") {
			return sortDirection === "asc"
				? aValue.localeCompare(bValue)
				: bValue.localeCompare(aValue);
		}

		return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
	});

	return (
		<div>
			<div className="flex justify-between items-center mb-4">
				<h2 className="text-xl font-semibold text-zinc-900">Email Campaigns</h2>
				{hasPermission(userRole, "emails", "create") && (
					<motion.a
						whileHover={{ scale: 1.02 }}
						whileTap={{ scale: 0.98 }}
						href="/admin/editor/email"
						className="flex items-center gap-1.5 bg-zinc-900 text-white px-3 py-1.5 rounded-xl hover:bg-zinc-800 transition-colors text-sm"
					>
						<Plus className="w-3.5 h-3.5" />
						Create Email
					</motion.a>
				)}
			</div>

			{/* Search */}
			<div className="relative mb-4">
				<Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-zinc-400" />
				<input
					type="text"
					placeholder="Search emails by subject or status..."
					value={searchQuery}
					onChange={(e) => setSearchQuery(e.target.value)}
					className="w-full pl-10 pr-4 py-2 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900 text-sm"
				/>
			</div>

			<div className="overflow-x-auto border border-zinc-200 rounded-xl">
				<table className="w-full">
					<thead>
						<tr className="border-b border-zinc-200 bg-zinc-50">
							<th
								onClick={() => handleSort("subject")}
								className="text-left py-3 px-4 font-semibold text-zinc-700 border-l border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
							>
								<div className="flex items-center">
									Subject
									{getSortIcon("subject")}
								</div>
							</th>
							<th
								onClick={() => handleSort("status")}
								className="text-left py-3 px-4 font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
							>
								<div className="flex items-center">
									Status
									{getSortIcon("status")}
								</div>
							</th>
							<th
								onClick={() => handleSort("recipients")}
								className="text-left py-3 px-4 font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
							>
								<div className="flex items-center">
									Recipients
									{getSortIcon("recipients")}
								</div>
							</th>
							<th
								onClick={() => handleSort("createdAt")}
								className="text-left py-3 px-4 font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
							>
								<div className="flex items-center">
									Created
									{getSortIcon("createdAt")}
								</div>
							</th>
							<th className="text-left py-3 px-4 font-semibold text-zinc-700 border-r border-zinc-200">
								Actions
							</th>
						</tr>
					</thead>
					<tbody>
						{isLoading ? (
							<TableSkeleton rows={5} columns={5} />
						) : error ? (
							<tr>
								<td colSpan={5} className="py-8 text-center text-zinc-500">
									Error loading emails. Please try again.
								</td>
							</tr>
						) : sortedEmails.length === 0 ? (
							<tr>
								<td colSpan={5} className="py-8 text-center text-zinc-500">
									{searchQuery
										? "No emails found matching your search."
										: "No emails found. Create your first email campaign!"}
								</td>
							</tr>
						) : (
							sortedEmails.map((email, index) => (
								<tr
									key={email.id}
									className={`${
										index === sortedEmails.length - 1
											? ""
											: "border-b border-zinc-200"
									} hover:bg-zinc-50 transition-colors`}
								>
									<td
										className="py-3 px-4 border-l border-r border-zinc-200 cursor-pointer"
										onClick={() => handleEditEmail(email)}
									>
										<div className="font-medium text-zinc-900 hover:text-zinc-600 transition-colors">
											{email.subject}
										</div>
									</td>
									<td className="py-3 px-4 border-r border-zinc-200">
										<span
											className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
												email.status === "published"
													? "bg-green-100 text-green-800"
													: email.status === "scheduled"
														? "bg-blue-100 text-blue-800"
														: "bg-yellow-100 text-yellow-800"
											}`}
										>
											{email.status || "draft"}
										</span>
									</td>
									<td className="py-3 px-4 text-zinc-600 border-r border-zinc-200">
										{email.recipients || 0}
									</td>
									<td className="py-3 px-4 text-sm text-zinc-600 border-r border-zinc-200">
										{formatDate(email.createdAt)}
									</td>
									<td className="py-3 px-4 border-r border-zinc-200">
										<div className="flex items-center gap-2">
											{allowedActions.map((action) => {
												if (action === "send" && email.status === "draft") {
													return (
														<motion.button
															key="send"
															whileHover={{ scale: 1.05 }}
															whileTap={{ scale: 0.95 }}
															onClick={(e) => {
																e.stopPropagation();
																handleSendEmail(email);
															}}
															className="p-2 text-zinc-400 hover:text-green-600 transition-colors"
															title="Send to Subscribers"
														>
															<Mail className="w-4 h-4" />
														</motion.button>
													);
												}
												if (action === "view") {
													return (
														<motion.button
															key="preview"
															whileHover={{ scale: 1.05 }}
															whileTap={{ scale: 0.95 }}
															onClick={(e) => {
																e.stopPropagation();
																handlePreviewEmail(email);
															}}
															className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors"
															title="Preview"
														>
															<Eye className="w-4 h-4" />
														</motion.button>
													);
												}
												return null;
											})}
											{/* Always show delete button with confirmation modal */}
											<motion.button
												whileHover={{ scale: 1.05 }}
												whileTap={{ scale: 0.95 }}
												onClick={(e) => {
													e.stopPropagation();
													handleDeleteEmail(email.id);
												}}
												className="p-2 text-zinc-400 hover:text-red-600 transition-colors"
												title="Delete"
											>
												<Trash2 className="w-4 h-4" />
											</motion.button>
										</div>
									</td>
								</tr>
							))
						)}
					</tbody>
				</table>
			</div>

			{/* Email Modal */}
			<AnimatePresence>
				{showEmailModal && (
					<motion.div
						initial={{ opacity: 0 }}
						animate={{ opacity: 1 }}
						exit={{ opacity: 0 }}
						className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
					>
						<motion.div
							initial={{ scale: 0.9, opacity: 0 }}
							animate={{ scale: 1, opacity: 1 }}
							exit={{ scale: 0.9, opacity: 0 }}
							className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col"
						>
							{/* Modal Header */}
							<div className="flex items-center justify-between p-4 border-b border-zinc-200">
								<h3 className="text-lg font-bold text-zinc-900">
									{editingEmail ? "Edit Email" : "Create Email"}
								</h3>
								<div className="flex items-center gap-3">
									<motion.button
										whileHover={{ scale: 1.02 }}
										whileTap={{ scale: 0.98 }}
										onClick={handleSaveEmail}
										className="flex items-center gap-2 px-4 py-1.5 text-sm bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl font-medium transition-colors"
									>
										<Save className="w-4 h-4" />
										{editingEmail ? "Update" : "Create"} Email
									</motion.button>
									<motion.button
										whileHover={{ scale: 1.02 }}
										whileTap={{ scale: 0.98 }}
										onClick={handleCloseModal}
										className="px-4 py-1.5 text-sm text-zinc-700 bg-zinc-100 hover:bg-zinc-200 rounded-xl font-medium transition-colors"
									>
										Cancel
									</motion.button>
									<button
										onClick={handleCloseModal}
										className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors"
									>
										<X className="w-4 h-4" />
									</button>
								</div>
							</div>

							{/* Modal Body */}
							<div className="flex-1 overflow-y-auto p-4 space-y-4">
								<div>
									<label className="block text-sm font-medium text-zinc-700 mb-2">
										Subject *
									</label>
									<input
										type="text"
										name="subject"
										value={emailForm.subject}
										onChange={handleEmailFormChange}
										className="w-full px-4 py-2 border border-zinc-300 rounded-xl focus:ring-2 focus:ring-zinc-500 focus:outline-none"
										placeholder="Email subject"
									/>
								</div>
								<div>
									<label className="block text-sm font-medium text-zinc-700 mb-2">
										Content *
									</label>
									<TiptapEditor
										placeholder="Start writing your email... Type / for commands"
										content={emailContent}
										onChange={setEmailContent}
										showPreview={true}
										onPreview={() => {
											if (emailForm.subject && emailContent) {
												const tempEmail = {
													subject: emailForm.subject,
													content: emailContent,
												};
												setEditingEmail(tempEmail);
												setShowEmailPreview(true);
											}
										}}
									/>
								</div>
							</div>
						</motion.div>
					</motion.div>
				)}
			</AnimatePresence>

			{/* Email Preview Modal */}
			<AnimatePresence>
				{showEmailPreview && editingEmail && (
					<motion.div
						initial={{ opacity: 0 }}
						animate={{ opacity: 1 }}
						exit={{ opacity: 0 }}
						className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
					>
						<motion.div
							initial={{ scale: 0.9, opacity: 0 }}
							animate={{ scale: 1, opacity: 1 }}
							exit={{ scale: 0.9, opacity: 0 }}
							className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col"
						>
							{/* Preview Header */}
							<div className="flex items-center justify-between p-4 border-b border-zinc-200">
								<div>
									<h3 className="text-lg font-bold text-zinc-900">
										Email Preview
									</h3>
									<p className="text-xs text-zinc-600 mt-1">
										{editingEmail?.subject ||
											emailForm.subject ||
											"Email Preview"}
									</p>
								</div>
								<div className="flex items-center gap-3">
									<motion.button
										whileHover={{ scale: 1.02 }}
										whileTap={{ scale: 0.98 }}
										onClick={async () => {
											const currentSubject =
												emailForm.subject || editingEmail?.subject || "";
											const currentContent =
												emailContent || editingEmail?.content || "";

											if (!currentSubject || !currentContent) {
												toast.warning("Email must have subject and content");
												return;
											}

											setConfirmData({
												title: "Send Email",
												message: "Send this email to all active subscribers?",
												variant: "info",
											});
											setConfirmAction(() => async () => {
												if (onSendEmail) {
													const emailToSend = {
														id: editingEmail?.id || "",
														subject: currentSubject,
														content: currentContent,
													};
													await onSendEmail(emailToSend);
													queryClient.invalidateQueries({
														queryKey: ["emails"],
													});
												}
											});
											setShowConfirmModal(true);
										}}
										className="px-4 py-1.5 text-sm bg-zinc-50 hover:bg-zinc-100 text-zinc-900 rounded-xl font-medium transition-colors border border-zinc-200"
									>
										Send to All Subscribers
									</motion.button>
									<motion.button
										whileHover={{ scale: 1.02 }}
										whileTap={{ scale: 0.98 }}
										onClick={() => setShowSendSingleModal(true)}
										className="px-4 py-1.5 text-sm bg-zinc-50 hover:bg-zinc-100 text-zinc-900 rounded-xl font-medium transition-colors border border-zinc-200"
									>
										Send to Single User
									</motion.button>
									<button
										onClick={() => setShowEmailPreview(false)}
										className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors"
									>
										<X className="w-4 h-4" />
									</button>
								</div>
							</div>

							{/* Preview Content */}
							<div className="flex-1 overflow-y-auto p-4">
								<div
									className="prose prose-zinc max-w-none"
									dangerouslySetInnerHTML={{
										__html: getEmailPreviewHTML(),
									}}
								/>
							</div>
						</motion.div>
					</motion.div>
				)}
			</AnimatePresence>

			{/* Send Single Email Modal */}
			<AnimatePresence>
				{showSendSingleModal && (
					<motion.div
						initial={{ opacity: 0 }}
						animate={{ opacity: 1 }}
						exit={{ opacity: 0 }}
						className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
					>
						<motion.div
							initial={{ scale: 0.9, opacity: 0 }}
							animate={{ scale: 1, opacity: 1 }}
							exit={{ scale: 0.9, opacity: 0 }}
							className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col"
						>
							{/* Modal Header */}
							<div className="flex items-center justify-between p-4 border-b border-zinc-200">
								<h3 className="text-lg font-bold text-zinc-900">
									Send Email to User
								</h3>
								<div className="flex items-center gap-3">
									<motion.button
										whileHover={{ scale: 1.02 }}
										whileTap={{ scale: 0.98 }}
										onClick={handleSendSingleEmail}
										className="flex items-center gap-2 px-4 py-1.5 text-sm bg-zinc-900 hover:bg-zinc-800 text-white rounded-xl font-medium transition-colors"
									>
										<Mail className="w-4 h-4" />
										Send
									</motion.button>
									<motion.button
										whileHover={{ scale: 1.02 }}
										whileTap={{ scale: 0.98 }}
										onClick={() => {
											setShowSendSingleModal(false);
											setSingleEmailForm({ email: "", name: "" });
										}}
										className="px-4 py-1.5 text-sm text-zinc-700 bg-zinc-100 hover:bg-zinc-200 rounded-xl font-medium transition-colors"
									>
										Cancel
									</motion.button>
									<button
										onClick={() => {
											setShowSendSingleModal(false);
											setSingleEmailForm({ email: "", name: "" });
										}}
										className="p-2 text-zinc-400 hover:text-zinc-600 transition-colors"
									>
										<X className="w-4 h-4" />
									</button>
								</div>
							</div>

							{/* Modal Body */}
							<div className="p-4 space-y-4">
								<div>
									<label className="block text-sm font-medium text-zinc-700 mb-2">
										Email Address *
									</label>
									<input
										type="email"
										name="email"
										value={singleEmailForm.email}
										onChange={handleSingleEmailFormChange}
										className="w-full px-4 py-2 border border-zinc-300 rounded-xl focus:ring-2 focus:ring-zinc-500 focus:outline-none"
										placeholder="user@example.com"
										required
									/>
								</div>
								<div>
									<label className="block text-sm font-medium text-zinc-700 mb-2">
										Name (Optional)
									</label>
									<input
										type="text"
										name="name"
										value={singleEmailForm.name}
										onChange={handleSingleEmailFormChange}
										className="w-full px-4 py-2 border border-zinc-300 rounded-xl focus:ring-2 focus:ring-zinc-500 focus:outline-none"
										placeholder="User name"
									/>
								</div>
								<div className="bg-zinc-50 p-3 rounded-xl border border-zinc-200">
									<p className="text-xs text-zinc-600 mb-1">
										<strong>Subject:</strong>{" "}
										{emailForm.subject || "No subject"}
									</p>
									<p className="text-xs text-zinc-500">
										Email will be sent with the current email content
									</p>
								</div>
							</div>
						</motion.div>
					</motion.div>
				)}
			</AnimatePresence>

			{/* Confirmation Modal */}
			<ConfirmationModal
				isOpen={showConfirmModal}
				onClose={() => {
					setShowConfirmModal(false);
					setConfirmAction(null);
				}}
				onConfirm={() => {
					if (confirmAction) {
						confirmAction();
					}
					setShowConfirmModal(false);
					setConfirmAction(null);
				}}
				title={confirmData.title}
				message={confirmData.message}
				confirmText="Confirm"
				cancelText="Cancel"
				variant={confirmData.variant}
			/>
		</div>
	);
};

export default EmailTab;
