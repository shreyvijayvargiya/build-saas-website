import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import Fuse from "fuse.js";
import {
	Users,
	Search,
	Mail,
	Calendar,
	CheckCircle2,
	XCircle,
	Trash2,
	ArrowUpDown,
	ArrowUp,
	ArrowDown,
} from "lucide-react";
import {
	collection,
	getDocs,
	query,
	orderBy,
	doc,
	deleteDoc,
} from "firebase/firestore";
import { db } from "../../../utils/firebase";
import TableSkeleton from "../../../lib/ui/TableSkeleton";
import ConfirmationModal from "../../../lib/ui/ConfirmationModal";
import { toast } from "react-toastify";

const CUSTOMERS_COLLECTION = "customers";

const getAllCustomers = async () => {
	try {
		const q = query(
			collection(db, CUSTOMERS_COLLECTION),
			orderBy("createdAt", "desc")
		);
		const querySnapshot = await getDocs(q);
		const customers = [];
		querySnapshot.forEach((doc) => {
			customers.push({
				id: doc.id,
				...doc.data(),
			});
		});
		return customers;
	} catch (error) {
		console.error("Error getting customers:", error);
		throw error;
	}
};

const CustomersTab = () => {
	const queryClient = useQueryClient();
	const [searchQuery, setSearchQuery] = useState("");
	const [showDeleteModal, setShowDeleteModal] = useState(false);
	const [customerToDelete, setCustomerToDelete] = useState(null);
	const [sortField, setSortField] = useState("createdAt");
	const [sortDirection, setSortDirection] = useState("desc");

	const {
		data: customers = [],
		isLoading,
		error,
	} = useQuery({
		queryKey: ["customers"],
		queryFn: () => getAllCustomers(),
	});

	// Delete customer mutation
	const deleteCustomerMutation = useMutation({
		mutationFn: async (customerId) => {
			const customerRef = doc(db, CUSTOMERS_COLLECTION, customerId);
			await deleteDoc(customerRef);
		},
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["customers"] });
			setShowDeleteModal(false);
			setCustomerToDelete(null);
			toast.success("Customer deleted successfully");
		},
		onError: (error) => {
			console.error("Error deleting customer:", error);
			toast.error("Failed to delete customer. Please try again.");
		},
	});

	const handleDeleteClick = (customer) => {
		setCustomerToDelete(customer);
		setShowDeleteModal(true);
	};

	const handleDeleteConfirm = () => {
		if (customerToDelete) {
			deleteCustomerMutation.mutate(customerToDelete.id);
		}
	};

	// Configure Fuse.js for customer search
	const fuse = useMemo(() => {
		return new Fuse(customers, {
			keys: ["email", "name", "customerId"],
			threshold: 0.3,
			includeScore: true,
		});
	}, [customers]);

	// Filter customers by search query using Fuse.js
	const filteredCustomers = useMemo(() => {
		if (!searchQuery.trim()) {
			return customers;
		}
		return fuse.search(searchQuery).map((result) => result.item);
	}, [searchQuery, fuse, customers]);

	// Handle column sort
	const handleSort = (field) => {
		if (sortField === field) {
			setSortDirection(sortDirection === "asc" ? "desc" : "asc");
		} else {
			setSortField(field);
			setSortDirection("asc");
		}
	};

	// Get sort icon for column header
	const getSortIcon = (field) => {
		if (sortField !== field) {
			return <ArrowUpDown className="w-3.5 h-3.5 ml-1 text-zinc-400" />;
		}
		return sortDirection === "asc" ? (
			<ArrowUp className="w-3.5 h-3.5 ml-1 text-zinc-900" />
		) : (
			<ArrowDown className="w-3.5 h-3.5 ml-1 text-zinc-900" />
		);
	};

	// Sort filtered customers
	const sortedCustomers = [...filteredCustomers].sort((a, b) => {
		let aValue, bValue;

		switch (sortField) {
			case "name":
				aValue = (a.name || "").toLowerCase();
				bValue = (b.name || "").toLowerCase();
				break;
			case "planName":
				aValue = (a.planName || "").toLowerCase();
				bValue = (b.planName || "").toLowerCase();
				break;
			case "status":
				aValue = (a.status || "").toLowerCase();
				bValue = (b.status || "").toLowerCase();
				break;
			case "amount":
				aValue = a.amount || 0;
				bValue = b.amount || 0;
				break;
			case "createdAt":
				aValue = a.createdAt?.toDate
					? a.createdAt.toDate().getTime()
					: new Date(a.createdAt || 0).getTime();
				bValue = b.createdAt?.toDate
					? b.createdAt.toDate().getTime()
					: new Date(b.createdAt || 0).getTime();
				break;
			case "customerId":
				aValue = (a.customerId || "").toLowerCase();
				bValue = (b.customerId || "").toLowerCase();
				break;
			default:
				return 0;
		}

		if (typeof aValue === "string") {
			return sortDirection === "asc"
				? aValue.localeCompare(bValue)
				: bValue.localeCompare(aValue);
		}

		return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
	});

	const formatDate = (date) => {
		if (!date) return "N/A";
		const d = date?.toDate ? date.toDate() : new Date(date);
		return d.toLocaleDateString("en-US", {
			year: "numeric",
			month: "short",
			day: "numeric",
		});
	};

	const formatCurrency = (amount, currency = "usd") => {
		// Handle null, undefined, or invalid amounts
		if (amount === null || amount === undefined) {
			return "N/A";
		}

		// Convert to number if it's a string
		const numAmount = typeof amount === "string" ? parseFloat(amount) : amount;

		// Check if it's a valid number (including 0)
		if (isNaN(numAmount)) {
			return "N/A";
		}

		// Amount is already in dollars (not cents), so don't divide by 100
		// Show $0.00 for free plans instead of N/A
		return new Intl.NumberFormat("en-US", {
			style: "currency",
			currency: currency.toUpperCase(),
		}).format(numAmount);
	};

	return (
		<div className="space-y-4">
			{/* Header */}
			<div className="flex items-center justify-between">
				<div>
					<h1 className="text-2xl font-bold text-zinc-900">Customers</h1>
					<p className="text-sm text-zinc-600 mt-1">
						Manage your paid customers and subscriptions
					</p>
				</div>
			</div>

			{/* Search */}
			<div className="relative">
				<Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-zinc-400" />
				<input
					type="text"
					placeholder="Search customers by email, name, or customer ID..."
					value={searchQuery}
					onChange={(e) => setSearchQuery(e.target.value)}
					className="w-full pl-10 pr-4 py-2 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900 text-sm"
				/>
			</div>

			{/* Table */}
			<div className="border border-zinc-200 rounded-xl overflow-hidden">
				<div className="overflow-x-auto">
					<table className="w-full min-w-[800px]">
						<thead className="bg-zinc-50 border-b border-zinc-200">
							<tr>
								<th
									onClick={() => handleSort("name")}
									className="py-3 px-4 text-left text-xs font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
								>
									<div className="flex items-center">
										Customer
										{getSortIcon("name")}
									</div>
								</th>
								<th
									onClick={() => handleSort("planName")}
									className="py-3 px-4 text-left text-xs font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
								>
									<div className="flex items-center">
										Plan
										{getSortIcon("planName")}
									</div>
								</th>
								<th
									onClick={() => handleSort("status")}
									className="py-3 px-4 text-left text-xs font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
								>
									<div className="flex items-center">
										Status
										{getSortIcon("status")}
									</div>
								</th>
								<th
									onClick={() => handleSort("amount")}
									className="py-3 px-4 text-left text-xs font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
								>
									<div className="flex items-center">
										Amount
										{getSortIcon("amount")}
									</div>
								</th>
								<th
									onClick={() => handleSort("createdAt")}
									className="py-3 px-4 text-left text-xs font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
								>
									<div className="flex items-center">
										Joined
										{getSortIcon("createdAt")}
									</div>
								</th>
								<th
									onClick={() => handleSort("customerId")}
									className="py-3 px-4 text-left text-xs font-semibold text-zinc-700 border-r border-zinc-200 cursor-pointer hover:bg-zinc-100 transition-colors"
								>
									<div className="flex items-center">
										Customer ID
										{getSortIcon("customerId")}
									</div>
								</th>
								<th className="py-3 px-4 text-left text-xs font-semibold text-zinc-700">
									Actions
								</th>
							</tr>
						</thead>
						<tbody>
							{isLoading ? (
								<tr>
									<td colSpan={7} className="py-8">
										<TableSkeleton rows={5} columns={7} />
									</td>
								</tr>
							) : error ? (
								<tr>
									<td colSpan={7} className="py-8 text-center text-zinc-500">
										Error loading customers. Please try again.
									</td>
								</tr>
							) : filteredCustomers.length === 0 ? (
								<tr>
									<td colSpan={7} className="py-8 text-center text-zinc-500">
										{searchQuery
											? "No customers found matching your search."
											: "No customers yet. Customers will appear here after they subscribe."}
									</td>
								</tr>
							) : (
								sortedCustomers.map((customer, index) => (
									<tr
										key={customer.id}
										className={`${
											index === filteredCustomers.length - 1
												? ""
												: "border-b border-zinc-200"
										} hover:bg-zinc-50 transition-colors`}
									>
										<td className="py-3 px-4 border-r border-zinc-200">
											<div>
												<div className="font-medium text-sm text-zinc-900">
													{customer.name || "N/A"}
												</div>
												<div className="text-xs text-zinc-600 flex items-center gap-1 mt-1">
													<Mail className="w-3 h-3" />
													{customer.email || "N/A"}
												</div>
											</div>
										</td>
										<td className="py-3 px-4 border-r border-zinc-200">
											<span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-zinc-900 text-white">
												{customer.planName || "Pro"}
											</span>
										</td>
										<td className="py-3 px-4 border-r border-zinc-200">
											{customer.status === "active" ? (
												<span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
													<CheckCircle2 className="w-3 h-3" />
													Active
												</span>
											) : (
												<span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
													<XCircle className="w-3 h-3" />
													{customer.status || "Inactive"}
												</span>
											)}
										</td>
										<td className="py-3 px-4 border-r border-zinc-200">
											{customer.amount !== null && customer.amount !== undefined
												? formatCurrency(customer.amount, customer.currency)
												: "N/A"}
										</td>
										<td className="py-3 px-4 border-r border-zinc-200">
											<div className="text-xs text-zinc-600 flex items-center gap-1">
												{formatDate(customer.createdAt)}
											</div>
										</td>
										<td className="py-3 px-4 border-r border-zinc-200">
											<code className="text-xs text-zinc-600 font-mono">
												{customer.customerId || customer.id}
											</code>
										</td>
										<td className="py-3 px-4">
											<button
												onClick={() => handleDeleteClick(customer)}
												className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
												title="Delete customer"
											>
												<Trash2 className="w-4 h-4" />
											</button>
										</td>
									</tr>
								))
							)}
						</tbody>
					</table>
				</div>
			</div>

			{/* Delete Confirmation Modal */}
			<ConfirmationModal
				isOpen={showDeleteModal}
				onClose={() => {
					setShowDeleteModal(false);
					setCustomerToDelete(null);
				}}
				onConfirm={() => {
					handleDeleteConfirm();
				}}
				title="Delete Customer"
				message={`Are you sure you want to delete customer "${customerToDelete?.name || customerToDelete?.email || "Unknown"}"? This action cannot be undone.`}
				confirmText="Delete"
				variant="danger"
			/>
		</div>
	);
};

export default CustomersTab;
